// ignore_for_file: camel_case_types

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:ostello/common/custom_container.dart';
import 'package:ostello/common/plaintext.dart';
import 'package:ostello/common/textformfield.dart';
import 'package:ostello/const/const_service.dart';
import 'package:ostello/data/provider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class homePage extends ConsumerWidget {
  const homePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextEditingController _searchContoller = TextEditingController();
    final selectedFilter = ref.watch(selectedFilterProvider);
    final PageController _pageController = PageController();
    _pageController.addListener(() {
      ref.read(currentPageProvider.notifier).state =
          _pageController.page?.round() ?? 0;
    });
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  SizedBox(
                      width: 230,
                      height: 44,
                      child: ReusableTextFormField(
                        controller: _searchContoller,
                        hintText: 'Search here...',
                        // obscureText: true,
                        suffix: const Icon(
                          Icons.search,
                          color: Color(0xff7D23E0),
                        ),
                      )),
                  const Spacer(),
                  CustomContainer(
                    height: 44,
                    width: 115,
                    decoration: BoxDecoration(
                        color: const Color(0xff7D23E0),
                        borderRadius: BorderRadius.circular(15)),
                    child: const Center(
                      child: PlainText(
                        name: 'Study',
                        fontsize: 16,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  )
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              SizedBox(
                height: 137,
                child: ListView.builder(
                    itemCount: constList.list1.length,
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      var item = constList.list1[index];
                      return Container(
                        width: 115,
                        margin: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(.1),
                                  spreadRadius: 3,
                                  blurRadius:
                                      2, // Blur radius controlled by elevation
                                  offset: const Offset(0, 2))
                            ]),
                        child: Column(
                          children: [
                            SizedBox(
                                height: 73,
                                width: 78,
                                child: Image.asset('${item["image"]}')),
                            PlainText(
                              name: '${item["text"]}',
                              fontsize: 14,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xff4C4452),
                            )
                          ],
                        ),
                      );
                    }),
              ),
              SizedBox(
                height: 135,
                child: ListView.builder(
                  controller: _pageController,
                  itemCount: 5,
                  // shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return Stack(
                      children: [
                        Container(
                            width: 360,
                            height: 150,
                            child: Image.asset(
                                'assets/images/Rectangle 20072.png')),
                        Positioned(
                          right: 20,
                          top: 20,
                          child: SizedBox(
                            height: 80,
                            width: 80,
                            child: Image.asset(
                              'assets/images/Rectangle 34624635.png',
                            ),
                          ),
                        ),
                        const Positioned(
                            top: 25,
                            left: 25,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                PlainText(
                                  name: 'Study with',
                                  fontsize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: Color(0xff2A2E3B),
                                ),
                                PlainText(
                                  name: 'India’s best Coaching Centres',
                                  fontsize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xff2A2E3B),
                                ),
                                PlainText(
                                  name: 'Anytime, Anywhere!',
                                  fontsize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: Color(0xff2A2E3B),
                                ),
                              ],
                            ))
                      ],
                    );
                  },
                ),
              ),
              Center(
                  child: SmoothPageIndicator(
                controller: _pageController,
                count: 5,
                effect: ExpandingDotsEffect(
                  dotHeight: 8,
                  dotWidth: 8,
                  expansionFactor: 3,
                  activeDotColor: const Color.fromARGB(255, 4, 58, 102),
                  dotColor: Colors.grey.shade400,
                ),
              )),
              const SizedBox(
                height: 25,
              ),
              const PlainText(
                name: 'Recommended for you',
                fontsize: 16,
                fontWeight: FontWeight.w400,
                color: Color(0xff272A34),
              ),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 137,
                child: ListView.builder(
                    itemCount: 6,
                    shrinkWrap: true,
                    padding: const EdgeInsets.all(0),
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return Stack(
                        children: [
                          Container(
                              width: 113,
                              height: 175,
                              child: Image.asset('assets/images/class3.jpg')),
                          const Positioned(
                              top: 6,
                              left: 13,
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.play_arrow,
                                    size: 12,
                                    color: Colors.white,
                                  ),
                                  PlainText(
                                    name: '2.5M',
                                    fontsize: 8,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white,
                                  ),
                                ],
                              )),
                          const Positioned(
                              bottom: 6,
                              left: 13,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  PlainText(
                                    name: 'Manoj Classes',
                                    fontsize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                  PlainText(
                                    name: 'Maths - 10th',
                                    fontsize: 10,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ],
                              )),
                        ],
                      );
                    }),
              ),
              const SizedBox(
                height: 30,
              ),
              const PlainText(
                name: 'Find the best Coach to help you\nwith your 10th Class',
                fontsize: 24,
                fontWeight: FontWeight.w800,
                color: Color(0xff696969),
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  Container(
                    width: 129,
                    height: 36,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xffD8D8D8))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                            height: 20,
                            width: 20,
                            child: Image.asset('assets/images/Frame (1).png')),
                        DropdownButton<String>(
                          alignment: Alignment.centerRight,
                          underline: Container(),
                          value: selectedFilter,
                          // isDense: true,

                          iconSize: 20,
                          items: filterOptions.map((String filter) {
                            return DropdownMenuItem<String>(
                              value: filter,
                              child: Text(
                                filter,
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.w600),
                              ),
                            );
                          }).toList(),
                          onChanged: (newValue) {
                            ref.read(selectedFilterProvider.notifier).state =
                                newValue!;
                          },
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: SizedBox(
                      height: 37,
                      // width: 500,
                      child: ListView.builder(
                          itemCount: constList.list3.length,
                          shrinkWrap: true,
                          padding: const EdgeInsets.all(0),
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, index) {
                            var item = constList.list3[index];
                            return Container(
                              width: 91,
                              margin: const EdgeInsets.only(left: 10),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  border: Border.all(
                                      color: const Color(0xffD8D8D8))),
                              child: Center(
                                child: PlainText(
                                  name: '${item["text"]}',
                                  fontsize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xff484848),
                                ),
                              ),
                            );
                          }),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 13,
              ),
              Container(
                height: 51,
                width: double.infinity,
                padding: const EdgeInsets.only(right: 30),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: const Color(0xffF3F4F8)),
                child: Stack(
                  children: [
                    const Align(
                      alignment: Alignment.centerRight,
                      child: PlainText(
                        name: 'Paid Courses',
                        fontsize: 16,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff737A87),
                      ),
                    ),
                    Positioned(
                        top: 3,
                        left: 5,
                        child: Container(
                          height: 45,
                          width: 170,
                          decoration: BoxDecoration(
                              color: const Color(0xff1C1C1C),
                              borderRadius: BorderRadius.circular(15)),
                          child: const Center(
                            child: PlainText(
                              name: 'Free Course',
                              fontsize: 16,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                        ))
                  ],
                ),
              ),
              const SizedBox(
                height: 23,
              ),
              const PlainText(
                name: 'Ongoing Classes',
                fontsize: 16,
                fontWeight: FontWeight.w800,
                color: Color(0xff737A87),
              ),
              const SizedBox(
                height: 12,
              ),
              Container(
                height: 275,
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Colors.white),
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Image.asset('assets/images/image 1376.png'),
                        Positioned(
                            top: 8,
                            right: 8,
                            child: Image.asset(
                                'assets/images/Frame 1597877865.png')),
                        Positioned(
                            bottom: 8,
                            right: 8,
                            child: Image.asset(
                                'assets/images/Frame 1597877864.png'))
                      ],
                    ),
                    Row(
                      children: [
                        Container(
                          height: 40,
                          width: 40,
                          decoration:
                              const BoxDecoration(shape: BoxShape.circle),
                          child: Image.asset('assets/images/Ellipse 1247.png'),
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 10, top: 15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              PlainText(
                                name: 'Physics - 10th Class',
                                fontsize: 18,
                                fontWeight: FontWeight.w800,
                                color: Color(0xff2E2E2E),
                              ),
                              SizedBox(
                                height: 3,
                              ),
                              Row(
                                children: [
                                  PlainText(
                                    name: 'Faculty Name',
                                    fontsize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xff4F4F4F),
                                  ),
                                  Icon(
                                    Icons.check_circle,
                                    color: Color(0xff878487),
                                    size: 15,
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 3,
                              ),
                              Row(
                                children: [
                                  PlainText(
                                    name: '476K views',
                                    fontsize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xff7C7C7C),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Icon(
                                    Icons.circle,
                                    color: Color(0xff878487),
                                    size: 7,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  PlainText(
                                    name: '3 days ago',
                                    fontsize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xff7C7C7C),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        const Spacer(),
                        const Padding(
                          padding: EdgeInsets.only(bottom: 20),
                          child: Icon(Icons.more_vert_rounded),
                        )
                      ],
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              Container(
                height: 120,
                padding: const EdgeInsets.only(left: 7),
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Colors.white,
                    border: Border.all(color: const Color(0xffE6E6E6))),
                child: Row(
                  children: [
                    SizedBox(
                        height: 95,
                        // width: 115,
                        child: Image.asset('assets/images/image 1376.png')),
                    Padding(
                      padding: const EdgeInsets.only(left: 8, top: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              PlainText(
                                name: 'Physics - 10th\nClass',
                                fontsize: 18,
                                fontWeight: FontWeight.w800,
                                color: Color(0xff2E2E2E),
                              ),
                              // Spacer(),
                              Padding(
                                padding: EdgeInsets.only(bottom: 20),
                                child: Icon(Icons.more_vert_rounded),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 2,
                          ),
                          const Row(
                            children: [
                              PlainText(
                                name: '476K views',
                                fontsize: 12,
                                fontWeight: FontWeight.w800,
                                color: Color(0xff7C7C7C),
                              ),
                              SizedBox(
                                width: 2,
                              ),
                              Icon(
                                Icons.circle,
                                color: Color(0xff878487),
                                size: 7,
                              ),
                              SizedBox(
                                width: 2,
                              ),
                              PlainText(
                                name: '3 days ago',
                                fontsize: 12,
                                fontWeight: FontWeight.w800,
                                color: Color(0xff7C7C7C),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 2,
                          ),
                          Row(
                            children: [
                              Container(
                                height: 20,
                                width: 20,
                                decoration:
                                    const BoxDecoration(shape: BoxShape.circle),
                                child: Image.asset(
                                    'assets/images/Ellipse 1247.png'),
                              ),
                              const SizedBox(
                                width: 3,
                              ),
                              const PlainText(
                                name: 'Institute Name',
                                fontsize: 14,
                                fontWeight: FontWeight.w800,
                                color: Color(0xff4F4F4F),
                              ),
                            ],
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              Container(
                height: 51,
                width: double.infinity,
                // padding: EdgeInsets.only(right: 30),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: const Color(0xffE7E8EC)),
                child: const Center(
                  child: PlainText(
                    name: 'View More Classes',
                    fontsize: 16,
                    fontWeight: FontWeight.w700,
                    color: Color(0xff737A87),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
