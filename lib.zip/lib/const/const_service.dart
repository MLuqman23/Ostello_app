class constList {
  static List list1 = [
    {"image": "assets/images/image 154.png", "text": "Career Trends"},
    {"image": "assets/images/image 155.png", "text": "Assessment"},
    {"image": "assets/images/image 154 (1).png", "text": "Popular Skills"}
  ];
  static List list2 = [
    {
      "image": "assets/images/Rectangle 20062.png",
    },
    {
      "image": "assets/images/Rectangle 20063.png",
    },
    {
      "image": "assets/images/Rectangle 20064.png",
    }
  ];
  static List list3 = [
    {"text": "Verified"},
    {"text": "Subjects"},
    {"text": "Rating"},
  ];
}
